%Plot line on figure = fig from origin (0, 0) with magnitude (length) 
% defined by mag and angle in degrees defined by ang.  Optional 
% color argument specified as short name 'r' = red, 'b' = blue, 'c' = cyan
% 'g' = green, 'y' = yellow, 'k' = black, 'w' = white or custom RGB color 
% normalized [R, G, B] where R, G and B are values between 0 and 1.

function plotPolD(fig, mag, ang, color)
%  [x, y] = pol2cart(ang * pi/180, mag)
  if nargin == 4
      C = color;
  else
      C = [.7, .2, .5];  %Bright Red
  figure(fig);
  x = mag * cos(ang * pi / 180);
  y = mag * sin(ang * pi / 180);
  
  plot([0, x], [0, y], 'Color', C);
end
