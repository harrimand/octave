%Plot line on figure = fig from origin (0, 0) to point (x, y) with optional 
% color argument specified as short name 'r' = red, 'b' = blue, 'c' = cyan
% 'g' = green, 'y' = yellow, 'k' = black, 'w' = white or custom RGB color 
% normalized [R, G, B] where R, G and B are values between 0 and 1.

function plotVector(fig, x, y, color)
  figure(fig);
  if nargin == 4
      C = color;
  else
      C = [.7, .2, .5];  %Bright Red
  end
  plot([0, x],[0, y], 'Color', C);
end
