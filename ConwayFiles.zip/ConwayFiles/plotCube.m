
function plotCube(mat)

% specifies all the vertices that comprises the object you want to draw

vert = [-0.5 -0.5 -0.5;  ...
        -0.5 0.5 -0.5;  ...
         0.5 0.5 -0.5;  ...
         0.5 -0.5 -0.5; ...
        -0.5 -0.5 0.5; ...
         -0.5 0.5 0.5;  ...
          0.5 0.5 0.5; ...
          0.5 -0.5 0.5];

% define the arbitrary polygon(patch) using the vertice number(index) you defined above.

fac = [1 2 3 4; ...
    2 6 7 3; ...
    4 3 7 8; ...
    1 5 8 4; ...
    1 2 6 5; ...
    5 6 7 8];          

    
%    mag = magic(4);

    clf;
    colors = colorcube(16);

    [szmr szmc] = size(mat);
    for r = 1:szmr
        for c = 1:szmc
            mat3D = vert + [r c mat(r,c)];
            color = colors(mat(r,c)+1,:);
            patch('Faces',fac,'Vertices',mat3D,'FaceColor',color);
        end
    end

%{
%            ind = (r-1) * 4 + c, 1:3;         
    cube = vert;
    cube(:,1) = cube(:,1) + 5; % X = 5
    cube(:,2) = cube(:,2) + 7; % Y = 7
    cube(:,3) = cube(:,3) + 4; % Z = 4
    
    coord = [3, 5, 4];
    cube1 = vert + coord;
    
    coordm = [4, 2, 5; 6, 3, 2];
%    cubes(1:2,:,:) = vert + coordm(1:2,:);
    cubes2 = vert + coordm(1,:);
    cubes3 = vert + coordm(2,:);
 
    


 

% specify patch (polygons) in patch() function

% just call the patch function multiple times to draw multiple cubes

patch('Faces',fac,'Vertices',vert,'FaceColor','r');  % draw the red cube
patch('Faces',fac,'Vertices',(1+vert),'FaceColor','b');  % draw the blue cube
patch('Faces',fac,'Vertices',(vert-1),'FaceColor','g');  % draw the green cube
patch('Faces',fac,'Vertices',(cube),'FaceColor','m');  % draw the magenta cube
patch('Faces',fac,'Vertices',(cube1),'FaceColor','k');  % draw the black cube
patch('Faces',fac,'Vertices',(cubes2),'FaceColor','g');  % draw the green cube
patch('Faces',fac,'Vertices',(cubes3),'FaceColor','r');  % draw the red cube
%patch('Faces',fac,'Vertices',(cubes),'FaceColor','g');  % draw the red cube
patch('Faces',fac,'Vertices',(magi),'FaceColor','g');  % draw the red cube
%}


axis([0 szmc+1 0 szmr+1 -1 9]);
grid();

% alpha('color');
% alphamap('rampdown');
view(30,30);

end
