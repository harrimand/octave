
function autocon(sz, reps, period)
%  autocon(sz, reps, period) Automatically calls conwayTest reps times.
%  sz = (integer) size of square random array of booleans passed to conwayTest
%  reps = (integer) number of times to start conwayTest
%  period = (float) update time for generations in conwayTest.
%  conwayTest will restart after 1 second pause until reps games completed.
%
%  See also:  conwayTest, neighbors, conway, plotCube, hexCell2bin, subMatWrite

    if nargin < 3
        period = 0;
    end  
  
  while(reps)
    M = round(rand(sz)) == 1;
    conwayTest(M, period);
    pause(1);
    reps = reps - 1;
  end
end
