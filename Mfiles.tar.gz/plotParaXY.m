function plotParaXY(Xrange, x, y)
  Y = y/x * Xrange.^2 / x;
  plot(Xrange, Y);
endfunction