

function xyPlot(fig, xRmin, xRmax, yRmin, yRmax)
  figure(fig);
  hold on;
  plot([xRmin, xRmax], [0, 0], 'LineWidth', 2); %Plot line on X Axis @ 0
  plot([0, 0], [yRmin, yRmax], 'LineWidth', 2); %Plot line on Y Axis @ 0
  xlim([xRmin, xRmax]);
  ylim([yRmin, yRmax]);
  grid on;
  set(gca, 'XMinorGrid', 'on');
  set(gca, 'YMinorGrid', 'on');
  
  %Set Tick Minor Grid Spacing
  xtickSize = 10;
  xtickStep = (xRmax - xRmin) / xtickSize;
  ytickSize = 10;
  ytickStep = (yRmax - yRmin) / ytickSize;
  
  set(gca, 'xtick', [xRmin:(xRmax - xRmin)/xtickStep: xRmax]);
  set(gca, 'ytick', [yRmin:(yRmax - yRmin)/ytickStep: yRmax]);
  
  set(gca, 'xcolor', [.7, .7, .7]); %Grid Line Colors 0..1
  set(gca, 'ycolor', [.7, .7, .7]);
  
  end;
 