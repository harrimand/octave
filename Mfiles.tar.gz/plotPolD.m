

function plotPolD(fig, mag, ang)
%  [x, y] = pol2cart(ang * pi/180, mag)
  x = mag * cos(ang * pi / 180);
  y = mag * sin(ang * pi / 180);
  
  plot([0, x], [0, y]);
end
