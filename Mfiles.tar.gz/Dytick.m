function Dytick(fig, tickSize)
  figure(fig);
  yMin = get(gca, 'ylim')(1);
  yMax = get(gca, 'ylim')(2);
  
  [-100 + mod(abs(-100), 30): 30: 100 - mod(abs(100), 30)]
  
  yTick = [yMin+mod(abs(yMin),tickSize):tickSize:yMax-mod(abs(yMax),tickSize)];
  
  set(gca, 'ytick', []);
  set(gca, 'YMinorGrid', 'off');
  
  set(gca, 'ytick', yTick);
  end
  