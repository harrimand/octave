

function Dxtick(fig, tickSize)
  figure(fig);
  xMin = get(gca, 'xlim')(1);
  xMax = get(gca, 'xlim')(2);
  
  xTick = [xMin+mod(abs(xMin),tickSize):tickSize:xMax-mod(abs(xMax),tickSize)];  
  
  set(gca, 'xtick', []);
  set(gca, 'XMinorGrid', 'off');
  
  set(gca, 'xtick', xTick);
  end
