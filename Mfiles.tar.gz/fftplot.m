## Copyright (C) 2018 Darrell Harriman
## 
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {Function File} {@var{retval} =} fftdemo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: Darrell Harriman <darrell@U64>
## Created: 2018-06-07

function [f, P1] = fftplot(X, Fs)
  
  L = length(X);
  Y = fft(X);
  P2 = abs(Y/L);
  P1 = P2(1:L/2+1);
  P1(2:end-1) = 2*P1(2:end-1);
  f = Fs*(0:(L/2))/L;
  figure(2);
  plot(f,P1) 
  title('Single-Sided Amplitude Spectrum of X(t)')
  xlabel('f (Hz)')
  ylabel('|P1(f)|')

endfunction
