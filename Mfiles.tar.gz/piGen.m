

function piIsh = piGen(n)
  iters = 1:n;
  terms = 1 ./ iters.^2;
  piIsh = sum(terms);
end
