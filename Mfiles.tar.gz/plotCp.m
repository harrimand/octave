

function plotCp(fig, cp)
  figure(fig);
  x = real(cp);
  y = imag(cp);
  plot([0, x], [0, y]);
end
