## Copyright (C) 2018 Darrell Harriman
## 
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {Function File} {@var{retval} =} fftdemo (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: Darrell Harriman <darrell@U64>
## Created: 2018-06-07

function [sinNoise Fs] = sin_noise()
  Fs = 1000;        %Sample Frequency (Samples per second)
  T = 1 / Fs;       %Sample Period
  SampleTime = 1.5; %Sample duration in seconds.
  L = SampleTime * Fs;  %Number of samples
  t = (0:L-1)*T;    %Row Vector of time iterations [T, 2T, 3T...]
  Sig1 = 0.7*sin(2*pi*50*t);
  Sig2 = sin(2*pi*120*t);
  Sig3 = .5 * sin(2 * pi * 200 * t);
  Sig4 = 2*randn(size(t));
  sinNoise = Sig1 + Sig2 + Sig3 + Sig4;
  
  plot(1000*t(1:50),sinNoise(1:50));
  title('Signal Corrupted with Zero-Mean Random Noise');
  xlabel('t (milliseconds)');
  ylabel('X(t)');
endfunction
