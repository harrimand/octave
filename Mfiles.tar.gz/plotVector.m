

function plotVector(fig, x, y)
  figure(fig);
  plot([0, x],[0, y])
end
