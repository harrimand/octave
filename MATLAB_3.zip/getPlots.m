% Get Plot Coordinates from all plots on figure(fig)
% plots contains begin(x,y) and end(x,y)
% begins contains begin(x,y).  (0,0) for plots from plotVector function.
% begins contains begin(x, 0) for plots from plotStem function
% ends contains end(x,y) for plots from plotVector and plotStem functions.  
% Usage:  [P1, B1, E1] = getPlots(1); %get plots from figure 1.
% E(1,:) will return [x, y] for the most recent plot.
% E(1,1) will return x and E(1,2) will return y for most recent plot.

function [plots, begins, ends] = getPlots(fig)
    figure(fig);
    j = findobj('type', 'line');
    P1 = [j(1:length(j)-1).XData; j(1:length(j)-1).YData]';
    n = 1:2:length(P1)-1;
    plots = [P1(n,:),P1(n+1,:)];
    begins = plots(:, 1:2);
    ends = plots(:, 3:4);
end
