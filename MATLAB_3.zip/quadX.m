function [X x] = quadX(a, b, c)
  X = (-b + sqrt(b^2 - 4 * a * c))/ (2 * a);
  x = (-b - sqrt(b^2 - 4 * a * c))/ (2 * a);
endfunction