%Plot line on figure = fig from origin (0, 0) to point specified by 
% a complex number.  X = real part and Y = imaginary part. 
% Optional color argument specified as short name
% 'r' = red, 'b' = blue, 'c' = cyan % 'g' = green, 'y' = yellow, 
% 'k' = black, 'w' = white or custom color may be
% normalized [R, G, B] where R, G and B are values between 0 and 1 or 
% 8 bit RGB where R, G and B are values between 0 and 255.

function plotCp(fig, cp, color)
  if nargin == 4
    if max(color) > 1
        C = color ./ 255;
      else 
        C = color;
      end
  else
      C = [.7, .2, .5];  %Bright Red
  end
  x = real(cp);
  y = imag(cp);
  figure(fig);
  plot([0, x], [0, y], 'Color', C);
end
