% Create Figure (Plot Window) scaled on X and Y axis.
% fig = figure number (integer 1..)
% X axis = xmin .. xmax
% Y axis = ymin .. ymax
% Defaults to 10 grid lines on X and Y axis.
% See functions Dxtick and Dytick to change grid spacing.
function xyPlot(fig, xmin, xmax, ymin, ymax)
  figure(fig);
  hold on;
  xMin = min([xmin, xmax]);
  xMax = max([xmin, xmax]);
  yMin = min([ymin, ymax]);
  yMax = max([ymin, ymax]);
  
  plot([xMin, xMax], [0, 0], 'LineWidth', 2); %Plot line on X Axis @ 0
  plot([0, 0], [yMin, yMax], 'LineWidth', 2); %Plot line on Y Axis @ 0
  xlim([xMin, xMax]);
  ylim([yMin, yMax]);
  
  grid on;
  set(gca, 'XMinorGrid', 'on');
  set(gca, 'YMinorGrid', 'on');
  
  %Set Tick Minor Grid Spacing
  xtickSize = 10;
  xtickStep = (xMax - xMin) / xtickSize;
  ytickSize = 10;
  ytickStep = (yMax - yMin) / ytickSize;
  
  set(gca, 'xtick', xMin:(xMax - xMin)/xtickStep: xMax);
  set(gca, 'ytick', yMin:(yMax - yMin)/ytickStep: yMax);
  
  set(gca, 'xcolor', [.2, .2, .2]); %Grid Line Colors 0..1
  set(gca, 'ycolor', [.2, .2, .2]);
end
