

function [tt] = truthTable(bits)
  tt = cast(dec2bin(0:2^bits-1)-48, 'uint8');
end

%printf('\t%d\t%d\t%d\t%d\t%d\n',TT(:,1),TT(:,2),TT(:,3),TT(:,4),TT(:,5))