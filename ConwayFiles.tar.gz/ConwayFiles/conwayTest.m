
function [M] = conwayTest(M, scrPause)
%  Calculate M(r,c) with Conway's Game of Life rules and plot.
%  Parameter M = starting Matrix of type 'logical' (boolean)
%  Optional Parameter scrPause sets period of time between updates.
%    if scrPause omitted, period will be calculation time.
%
%  Author:  Darrell Harriman  harrimand@gmail.com
%
%  Conway's Game of Life Rules:
%  If M(r,c) == 1 and sum_of_neighbors = 2 or 3 new M(r,c)=1 else new M(r,c)=0
%  If M(r,c) == 0 and sum_of_neighbors = 3 new M(r,c)=1 else new M(r,c)=0
%
%  Example Usage:
%  >> M = round(rand(64))==1; %creating 64x64 matrix of random boolean 1s or 0s.
%  >> M = conwayTest(M); % Function updates plot until 'x' is entered on console
%     % conwayTest will stop if neighbors() detects no growth or decay in matrix
%
%  See also:  conway, subMwrap, neighbors, subMatWrite

  if nargin < 2
    scrPause = 0;
  end

  disp('Enter x in console to stop Conways Game of Life');
  fflush(stdout);
  [r c] = size(M);  % r = rows  c = columns
  [sum3_3 done] = neighbors(M, 1);  % getting neighbor count
%  sum3_3 = conway(M); % Sum of neighbors including wrapped top-bottom side-side
  M = M & (sum3_3 > 1) & (sum3_3 < 4) | (!M & (sum3_3 == 3));

% figure(fig#, 'position', [x y width height]);
% x = pixels from left side of screen to left side of figure.
% y = pixels from bottom of screen to bottom of figure.
  scsz = get(0, 'screensize')(3:4);
  % Centering 900x900 window on screen.
  figure(1, 'position', [scsz(1)/2-450 (scsz(2)-900)/2 900 900]);
  imagesc((1:r)+0.5, (1:c)+0.5, M); % Plot Matrix
  colormap(gray);
  axis equal;
  set(gca, 'XTick', 1:(c+1), 'YTick', 1:(r+1), ...
         'XLim', [1 c+1], 'YLim', [1 r+1], ...
         'GridLineStyle', '-', 'XGrid', 'on', 'YGrid', 'on');

  tstart = tic();
  tperiod = tstart;
  generations = 1;

  while (~ done)  % kbhit not available in MatLab.
    if kbhit(1) == 'x' % Enter 'x' in console to stop
      printf('\n Stopped by user.\n');
      break
    end
    
    [sum3_3 done] = neighbors(M, 0);
%    sum3_3 = conway(M); % neighbors() is much faster.
%   Check neighbor counts to determine if cells live, die, or spawn.
    M = M & (sum3_3 > 1) & (sum3_3 < 4) | (!M & (sum3_3 == 3));
    imagesc((1:r)+0.5, (1:c)+0.5, M);
    generations ++;
    title(['Generations: ' num2str(generations)], 'FontSize', 16);

    figure(2);
    plotCube(sum3_3);
    figure(1);
    
    while(toc(tperiod) < scrPause); %Pause until scrPause time ellapsed.
    end
    tperiod = tic();  % Get current tics (time)
  end

  runtime = toc(tstart);
  printf('  Rows: %d  Columns: %d  Cells: %d\n', r, c, r * c);
  printf('  Run Time = %f seconds.\n', runtime);
  printf('  Generations = %d\n', generations);
  printf('  Average generation time = %f seconds.\n', runtime / generations);
  printf('  Generations Per Second: %f\n\n', generations / runtime );
end
