
function [M] = hexCell2bin(hexCell)
% hexCell2bin(hexCell) returns boolean Matrix from cell array of hex values.
%
% Example Cell Array: {" 40, 40, A0, 40, 40, 23, 3, 3C 0 8 6 "}
%   Cell Array Hex Values are delimited by commas or spaces.
% Returns Matrix of type 'Logical' (boolean)
%{
     Example:  [ 0 1 0 0 0 0 0 0;
                 0 1 0 0 0 0 0 0;
                 1 0 1 0 0 0 0 0;
                 0 1 0 0 0 0 0 0;
                 0 1 0 0 0 0 0 0;
                 0 0 1 0 0 0 1 1;
                 0 0 0 0 0 0 1 1;
                 0 0 1 1 1 1 0 0;
                 0 0 0 0 0 0 0 0;
                 0 0 0 0 1 0 0 0;
                 0 0 0 0 0 1 1 0 ];
              
 %}
%
% See also:  subMatWrite, 
 
M = dec2bin(hex2dec(strsplit(strtrim(hexCell{1}),{",", " "})))(:,:) == '1'
  
  end  

%{
D = cast(dec2bin(hex2dec(num2str(Hex)))(1:end),'uint8')-48
HexH = num2str(Hex);

M(:, L:8) = cast(dec2bin(hex2dec(HexH))(1:end),'uint8')-48

% disp(num2str(Hex))

end

%--------------------------------------------------

hexCellL = {" 40, 40, A0, 40, 40, 23, 3, 3C 0, 8, 6 "}
wkndL = dec2bin(hex2dec(strsplit(strtrim(hexCellL{1}),{",", " "})))(:,:) == '1'
wkndR = wkndL(:,8:-1:1)
wknd = horzcat(wkndL, wkndR)
[szwkndR szwkndL] = size(wknd);

%--------------------------------------------------
copperheadCell = {' 1 3 0 7 3 0 6 1A 2 0 0 1 1'};
copMatL = dec2bin(hex2dec(strsplit(strtrim(copperheadCell{1}),{",", " "})))(:,:) == '1';
copMat = horzcat(copMatL, copMatL(:,5:-1:1));
[szcopR szcopL] = size(copMat);

%--------------------------------------------------
% Mid Weight Space Ship Moving Left
midWeightCell = {' 0E 1F 37 18'};
midWeightMat = dec2bin(hex2dec(strsplit(strtrim(midWeightCell{1}),{",", " "})))(:,:) == '1';
[szMwR szMwC] = size(midWeightMat)

%--------------------------------------------------
% Mid Weight Space Ship Moving Up
midWeightCell = {' 0E 1F 37 18'};
midWeightMat = dec2bin(hex2dec(strsplit(strtrim(midWeightCell{1}),{",", " "})))(:,:) == '1';
mwUp = rot90(midWeightMat, -1);
[szMwUpR szMwUpC] = size(mwUp)

%--------------------------------------------------

%}