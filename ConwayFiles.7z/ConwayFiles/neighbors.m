
function [count, done] = neighbors(M, init)
%  neighbors(M, init) counts neighbors for each cell.
%  Returns matrix of counts.
%  If init true, initialize persistent variables.
%  Saves counts on odd cycles and compares on even cycles to detect 
%      when growth or decay has ceased.
%  done = true when comparison cycle and cycle-2 match.
%  Count neighbors by making 8 copies of M shifted Left, Right, 
%      Up, Down, and diagonal Up-Left, Up-Right, Down-left and Down-Right.
%  All copies are added on the Z axis to get counts.
%
%  Example:  M = round(rand(64)) == 1; % Create 64x64 matrix of random 1s + 0s
%    [sum3_3 done] = neighbors(M, 1);
%    M = M & (sum3_3 > 1) & (sum3_3 < 4) | (!M & (sum3_3 == 3));
%    while( ~ done)
%        [sum3_3 done] = neighbors(M, 0);
%        M = M & (sum3_3 > 1) & (sum3_3 < 4) | (!M & (sum3_3 == 3));
%    end
%
%  See also:  conwayTest, conway, autocon, hexCell2bin, conSpace.mat

  m(:,:,8) = shift(M, -1, 2);         %shift Left
  m(:,:,7) = shift(M, 1, 2);          %shift Right
  m(:,:,6) = shift(M, -1, 1);         %shift Up
  m(:,:,5) = shift(M, 1, 1);          %shift Down
  m(:,:,4) = shift(m(:,:,8), -1, 1);  %shift up-left
  m(:,:,3) = shift(m(:,:,7), -1, 1);  %shift up-right
  m(:,:,2) = shift(m(:,:,8), 1, 1);   %shift down-left
  m(:,:,1) = shift(m(:,:,7), 1, 1);   %shift down-right
  
  count = cast(sum(m, 3), 'uint8'); % Matrix of counts of neighbors

  persistent evencycleCount;
  persistent evencycle;  
  persistent done;
  
  if init
    evencycleCount = count;
    evencycle = true;
    done = false;
  else
    evencycle = ~evencycle;
%  end

  if evencycle
    if count == evencycleCount
      done = true;
      clear evencycleCount;
      clear evencycle;
    else
      evencycleCount = count;
    end
  end
end


%{  Version 1 of code works but is slower. 
%  tstart = tic;

  mW =  shift(M, -1, 2);
  mE =  shift(M, 1, 2);
  mN =  shift(M, -1, 1);
  mS =  shift(M, 1, 1);
  mNW = shift(mW, -1, 1);
  mNE = shift(mE, -1, 1);
  mSW = shift(mW, 1, 1);
  mSE = shift(mE, 1, 1);
  
  count = cast(mW + mE + mN + mS + mNW + mNE + mSW + mSE, 'uint8');
% toc(tstart);
%}  