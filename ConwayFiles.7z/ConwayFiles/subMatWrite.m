
function [Mat] = subMatWrite(Mat, subMat, row, col)
%  subMatWrite(Mat, subMat, row, col) Writes subMat to Mat at row, col.
%
%  Mat = larger matrix with cells to be overwritten with subMat
%  subMat = smaller matrix to be written to Mat
%  row = row number location for top of subMat
%  col = column number location for left side of subMat
%
%  Verifies submatrix will fit inside Mat at (row, col)
%
%  See also:  hexCell2bin, subMwrap

  [szMatR szMatC] = size(Mat);
  [r c] = size(subMat);
  
  if ( szMatR >= (row + r - 1) && szMatC >= (col + c - 1))
    Mat(row:row + r - 1, col:col + c - 1) = subMat;
%    M = Mat;
  else
    error('Out of Bounds');
end
 