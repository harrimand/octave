function potRead(a)
% requires command a = arduino;
% requires Matlab Arduino Libraries
    figure()
    cx = cos(0:2*pi/20:2*pi);
    cy = sin(0:2*pi/20:2*pi);
    % C = plot(cx+3, cy, 'color', 'r');
    C = fill(cx+3, cy, 'r');
        
    set(gca, 'xlim', [-1, 6], 'ylim', [-1, 6])
        
    while(1)
        potX = readVoltage(a, 'A0');
        potY = readVoltage(a, 'A1');
        % fprintf('Voltage: %f\n', pot)
        set(C, 'xdata', cx + potX)
        set(C, 'ydata', cy + potY)
        pause(.02)
    end