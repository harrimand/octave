function [dt, data] = daq(a)
    close
    tic;
    data = [];
    dt = [];
    dInd = 1;
    toc;
    T = 0;
    while(T < 10)
        data(dInd) = readVoltage(a, 'A0');
        T = toc;
        dt(dInd) = T;
        dInd = dInd + 1;
    end
    fprintf('Samples: %d\n', length(dt))
    T = toc;
    fprintf('Elapsed Time: %f\n', T)
    figure()
    plot(dt, data)
    set(gca, 'ylim', [-1, 6])
end

