

function [E L C T] = ELCT()
  Et = [1+1i, 1.8+1i, 1.8+1.2i, 1.2+1.2i, 1.2+1.4i, 1.6+1.4i, 1.6+1.6i,...
  1.2+1.6i, 1.2+1.8i, 1.8+1.8i, 1.8+2i, 1+2i, 1+1i];
  
  E = Et .+ (0+0i);
  
  Lt = [1+1i, 1.8+1i, 1.8+1.2i, 1.2+1.2i, 1.2+2i, 1+2i, 1+1i];
  
  L = Lt .+ (1+0i);
  
  Ct = [1+1i, 1.8+1i, 1.8+1.2i, 1.2+1.2i, 1.2+1.8i, 1.8+1.8i, 1.8+2i,...
  1+2i, 1+1i];
  
  C = Ct .+ (2+0i);
  
  Tt = [1.3+1i, 1.5+1i, 1.5+1.8i, 1.8+1.8i, 1.8+2i, 1+2i, 1+1.8i,...
  1.3+1.8i, 1.3+1i]; 
  
  T = Tt .+ (3+0i);
  
  plotELCT(E, L, C, T);
  plotELCTtran3x45(E, L, C, T);

end

function plotELCT(E, L, C, T)
  plotComplexLine(1, E);
  plotComplexLine(1, L);
  plotComplexLine(1, C);
  plotComplexLine(1, T);
end

function plotELCTtran3x45(E, L, C, T)
  plotComplexLine(1, E .* pold2cplx(3, 45) + (4+0i));
  plotComplexLine(1, L .* pold2cplx(3, 45) + (4+0i));
  plotComplexLine(1, C .* pold2cplx(3, 45) + (4+0i));
  plotComplexLine(1, T .* pold2cplx(3, 45) + (4+0i));
end
