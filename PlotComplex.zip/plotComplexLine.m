

% house = [2 + 3i, 2 + 1i, 4 + 1i, 4 + 3i, 2 + 3i, 3 + 4i, 4 + 3i]
% Multiply house by complex number  house .* (4 + 3i)
% zooms in on house by magnitude = sqrt(4^2 + 3^2) = 5 times.
% rotates house by angle atan(3/4) = 36.9 degrees.

function plotComplexLine(fig, compPoints, Close)
  figure(fig);
  hold on;
%  if nargin > 2
  
  
  Plen = length(compPoints);
  for i = 1:Plen-1
    x1 = real(compPoints(i));
    y1 = imag(compPoints(i));
    x2 = real(compPoints(i+1));
    y2 = imag(compPoints(i+1));
    % Plot line from last point to first point if
    %     for i = 1:Plen and uncomment next 2 lines.
    % x2 = real(compPoints(mod(i,length(compPoints))+1));
    % y2 = imag(compPoints(mod(i,length(compPoints))+1));
    plot([x1, x2],[y1, y2])
  endfor
end
