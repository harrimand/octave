# Created by Octave 4.0.0, Fri Jun 15 23:58:51 2018 PDT <darrell@U64>
# name: M
# type: matrix
# rows: 3
# columns: 3
 4 8 -5
 8 32 -9
 12 16 10


# name: M1
# type: matrix
# rows: 3
# columns: 3
 4 8 -5
 0 16 1
 12 16 10


# name: M2
# type: matrix
# rows: 3
# columns: 3
 4 8 -5
 0 16 1
 0 -8 25


# name: M3
# type: matrix
# rows: 3
# columns: 3
 4 8 -5
 0 16 1
 0 0 25.5


# name: MP
# type: matrix
# rows: 3
# columns: 3
 19 5.5 -5
 -3 16.5 1
 -18 21 10


# name: Mprod
# type: matrix
# rows: 3
# columns: 3
 1 0 0
 -2 1 0
 -4 0.5 1


# name: Res2
# type: matrix
# rows: 3
# columns: 3
 4 8 -5
 0 16 1
 0 0 25.5


# name: V
# type: matrix
# rows: 3
# columns: 1
 139
 467
 246


# name: Vp
# type: matrix
# rows: 3
# columns: 1
 139
 189
 -76.5


# name: ans
# type: matrix
# rows: 3
# columns: 3
 4 8 -5
 8 32 -9
 12 16 10


# name: w
# type: scalar
7


# name: x
# type: scalar
12


# name: y
# type: scalar
-3


