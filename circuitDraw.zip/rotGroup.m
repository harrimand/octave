% rotGrp
function rotGroup(hGrp, dTh)
% rotate group by dTh degrees

    Ch = get(hGrp, 'Children');
    chLen = length(Ch);

    for g = 1:chLen
        rotate(Ch(g), [0, 0, 1], dTh)
    end
end
