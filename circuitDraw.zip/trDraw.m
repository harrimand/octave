% trDraw
function trGrp =  trDraw(cr, trX, trY)
% Draw transistor with radius cr at coordinates trX, trY
%
    cx = cr .* cos(0:pi/30:2*pi);
    cy = cr .* sin(0:pi/30:2*pi);

    % Base
    baseTx = cr * cos(3 * pi / 4);
    baseTy = cr * sin(3 * pi / 4);
    baseBx = cr * cos(5 * pi / 4);
    baseBy = cr * sin(5 * pi / 4);

    % Collector
    cBx = baseTx;
    cBy = (baseTy - baseBy) * .6 + baseBy;
    cCx = cr * cos(3 * pi / 8);
    cCy = cr * sin(3 * pi / 8);

    % Emitter
    eBx = baseTx;
    eBy = (baseTy - baseBy) * .4 + baseBy;
    eCx = cr * cos(-3 * pi / 8);
    eCy = cr * sin(-3 * pi / 8);

    % Pins
    pinExT = eCx;
    pinExB = eCx;
    pinEyT = eCy;
    pinEyB = pinEyT - .2 * cr;

    pinCxT = cCx;
    pinCxB = cCx;
    pinCyT = cCy;
    pinCyB = pinCyT + .2 * cr;

    pinBxL = -1.1 * cr;
    pinBxR = baseTx
    pinByL = pinByR = 0;

    trGrp = hggroup();
    trFormat = {'linewidth', 3, 'Parent', trGrp};
    hTr = plot(cx+trX, cy+trY, trFormat{:});
    hTrB = line([baseTx, baseBx] + trX, [baseTy, baseBy] + trY, trFormat{:});
    hTrC = line([cBx, cCx] + trX, [cBy, cCy] + trY, trFormat{:});
    hTrE = line([eBx, eCx] + trX, [eBy, eCy] + trY, trFormat{:});
    hTrpinE = line([pinExT, pinExB] + trX, [pinEyT, pinEyB] + trY, trFormat{:});
    hTrpinC = line([pinCxT, pinCxB] + trX, [pinCyT, pinCyB] + trY, trFormat{:});
    hTrpinB = line([pinBxL, pinBxR] + trX, [pinByL, pinByR] + trY, trFormat{:});
    arrow1 = line([eCx, eCx-.2*cr] + trX, [eCy, eCy+.3*cr] + trY, trFormat{:});
    arrow2 = line([eCx, eCx-.33*cr] + trX, [eCy, eCy+.07*cr] + trY, trFormat{:});
end
