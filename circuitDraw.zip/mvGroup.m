function mvGroup(hGrp, dx, dy)

Ch = get(hGrp, 'Children');
chLen = length(Ch);

for g = 1:chLen
    set(Ch(g), 'Xdata', get(Ch(g), 'Xdata') + dx)
    set(Ch(g), 'Ydata', get(Ch(g), 'Ydata') + dy)
end

